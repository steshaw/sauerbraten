TriggerTest

a demonstration map 
for Sauerbraten
by MeatROme

2006-10-10

-------------------------------------

unpack into your sauerbraten folder
run sauerbraten
enter "/mode -2;map trgtst"
enjoy
